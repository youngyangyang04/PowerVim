package lint

import "fmt"

func MissingDoc() {
	fmt.Println("missing doc")
}
